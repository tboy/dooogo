var map = null,
    position = null,
    marker = null,
    circle = null,
    infoWin = null,
    searchService = null,
    poiList = null,
    maplng = null,
    maplat = null,
    mapradius = 500,
    setMapData = [],
    geocoder = null;

var initMap = function () {

    map = new qq.maps.Map(document.getElementById('container'), {
        zoom: 13
    });
    //获取城市列表接口设置中心点
    citylocation = new qq.maps.CityService({
        complete : function(result){
            map.setCenter(result.detail.latLng);
        }
    });
    //调用searchLocalCity();方法    根据用户IP查询城市信息。
    citylocation.searchLocalCity();

    
    
    //调用Poi检索类
    searchService = new qq.maps.SearchService({
        map : map,
        complete:function(result){
            console.log(result)
            var infoDiv = document.getElementById('infoDiv');
            if(result.type == 'POI_LIST'){
                poiList = result.detail.pois;
                infoDiv.innerHTML='';
                for(let i of poiList){
                    var p = document.createElement("p");
                    p.innerHTML = i.name;
                    p.onclick = function(){

                        maplat = i.latLng.lat;
                        maplng = i.latLng.lng;
                        mapClickNewCover(i.latLng.lat,i.latLng.lng);
                        infoDiv.classList.remove();
                    }
                    infoDiv.appendChild(p); 
                }
                infoDiv.classList.add("infomap-search");
            }else{
                clearOverlays();
                infoDiv.classList.remove("infomap-search");
            }
        }
    });
    

    function qqMapAddListener(){
        var listener = qq.maps.event.addListener(
            map,
            'click',
            function (event) {
                maplat = event.latLng.getLat();
                maplng = event.latLng.getLng();
                console.log(event)
                mapClickNewCover(event.latLng.getLat(),event.latLng.getLng())
            }
        );
    }
    qqMapAddListener();

}
//清除覆盖物的函数
function clearOverlays() {
    if(circle){
        circle.setMap(null);
    }
    if(marker){
        marker.setMap(null);
    }
    if(infoWin){
        infoWin.setMap(null);
    }
}
function mapClickNewCover(lat,lng){
    clearOverlays();
    position = new qq.maps.LatLng(lat, lng);
    //创建marker
    marker = new qq.maps.Marker({
        position: position,
        map: map
    });
    mapGeocoderFun();
    mapCircleFun();
}
function mapGeocoderFun(){
    geocoder = new qq.maps.Geocoder({});
    geocoder.setComplete(function (result) {
        var geocoderResult = result.detail;
        infoWin = new qq.maps.InfoWindow({
            map: map
        });
        infoWin.open();
        //tips  自定义内容
        let abc = 'bbb'
        infoWin.setContent('<div id="mapinfo" style="width:200px;">' +
            '<p>' + geocoderResult.nearPois[0].name + '</p>' +
            '<p>' + geocoderResult.nearPois[0].address + '</p>' +
            '<input type="text" class="mapRadiusInput" id="mapRadiusInput" onblur="getChangeRadius()">' + 
            '<a href="javascript:;" class="btn-radius" onclick="getChangeRadius()">确定</a>' + 
            '</div>');
        infoWin.setPosition(position);


        infoWin.closeclick=function(){
            alert(123)
        };
        

    });
    geocoder.getAddress(position);
}

function mapCircleFun(){
    console.log(mapradius)
    circle = new qq.maps.Circle({
        //圆形的中心点坐标。
        center: position,
        //圆形是否可点击。
        clickable: true,
        //鼠标在圆形内的光标样式。
        cursor: 'pointer',
        //圆形的填充色，可通过Color对象的alpha属性设置透明度。
        // fillColor: "#00f",
        fillColor: new qq.maps.Color(40, 173, 39, 0.2),
        //要显示圆形的地图。
        map: map,
        //圆形的半径。
        radius:  mapradius,
        //圆形的边框颜色，可通过Color对象的alpha属性设置透明度。
        strokeColor: "#38c82d",
        //圆形的边框样式。实线是solid，虚线是dash。
        strokeDashStyle: "solid",
        //圆形的边框线宽。
        strokeWeight: 3,
        editable: true,
        //圆形是否可见。
        visible: true,
        //圆形的zIndex值。
        zIndex: 1000
    });
}

function getChangeRadius(){
    mapradius = Number(document.getElementById('mapRadiusInput').value) || mapradius;
    // alert(maplng);
    console.log(maplat,maplng,mapradius)
    if(mapradius){
        circle.setRadius(mapradius);
        setMapData = [{name:'厦门'},{name:'漳州'}];
        // console.log(setMapData)
    }

    
}
function getSynicDataInfo(item){
    $.ajax({
        type:'post',
        data:{},
        dataType:'json',
        success:function(){

        },
    })
}


