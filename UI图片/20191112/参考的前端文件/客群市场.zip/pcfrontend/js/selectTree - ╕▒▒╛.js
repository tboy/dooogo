var selectTreeTemplate = 
`<div class="select-tree-module">
    <div class="total-select">已选择 {{selectData.length}}/50</div>
    <div class="select-tree-content">
      <div class="tree-unit" v-for="(item,idx) in selectData" :key="idx">
        {{item.name}}
        <a href="javascript:;" @click="delSelectTree(selectData,idx)">删除</a>
      </div>
    </div>
    <div class="select-tree-compoent">
       

        <template v-for="(column,key) in treeColumnArr">
        <div class="tree-view">
          <ul>
            <template v-for="(item,idx) in column">
            <li :key="idx">
                <el-checkbox label="item.id" 
                  :value="item.checked" 
                  :indeterminate ="item.indeterminate"
                  @change="changeTreeSelect2(item,key)">{{item.name}}
                </el-checkbox>{{item.checked}}
            </li>
            </template>
          </ul>
        </div>
        </template>


    </div>
</div> `;


Vue.component('select-tree', {
  data() {
    return {
      treeDataArr:this.data,
      selectData:[],
      treeColumnArr:[]
    }
  },
  props: {
    data:{type:Array}
  },
  template: selectTreeTemplate,
  mounted(){
    // this.firstColumnView();
    //this.changeTreeSelect('', -1)
    this.createLevel('', 0)
    console.log(this.treeDataArr)
    this.showTree('')
  },
  watch:{
  },
  methods:{
    createLevel (parent_name, level) {
      const column = []
      for(let item of this.treeDataArr){
        if(item.parent_name === parent_name){
          item.level = level
          column.push(item);
        }
      }
      if(column.length){
        column.forEach(item => {
          this.createLevel(item.name, level + 1)
        })
      }
    },
    showTree (parent_name) {
      const result = this.treeDataArr.filter(item => {
        return item.parent_name === parent_name
      })
      if(result.length){
        const level = result[0].level
        this.treeColumnArr[level] = result
        this.showTree(result[0].name, true)
      } else {
        const current = this.treeDataArr.filter(item => {
          return item.name === parent_name
        })[0]
        this.treeColumnArr = this.treeColumnArr.slice(0, current.level + 1)
      }
    },
    changeTreeSelect2 (item) {
      this.showTree(item.name)
      const level = item.level
      item.checked = !item.checked
      item.indeterminate = false
      let offset = 1
      while(this.treeColumnArr[level + offset]) {
        this.treeColumnArr[level + offset].forEach( i => {
          i.checked = item.checked
        })
        offset++
      }

      this.existParentCheck(item);

      
    },
    existParentCheck(item){
      if (item.level !== 0) {
        const current = this.treeDataArr.filter(i => {
          return i.name === item.parent_name
        })[0]
        const existNoCheckedChild = this.treeColumnArr[item.level].filter(i => {
          return !i.checked
        }).length > 0
        const existCheckedChild = this.treeColumnArr[item.level].filter(i => {
          return i.checked
        }).length > 0
        current.indeterminate = false
        if (existCheckedChild && !existNoCheckedChild) {
          current.checked = true
        } else if (existCheckedChild && existNoCheckedChild) {
          // current.checked = true
          current.indeterminate = true
        } else {
          current.checked = false
        }
        this.existParentCheck(current);
      }
    },
    changeTreeSelect(row,idx){
      let column = [],name='';
      name = !row? row :row.name;
      for(let item of this.treeDataArr){
        if(item.parent_name === name){
          column.push(item);
        }
      }
      
      if(column.length){
        if(idx<0){
          this.treeColumnArr.push(column);
        }else if(idx<this.treeColumnArr.length){
          this.treeColumnArr.splice(idx+1,1,column);
        }
      }
      row.checked = !row.checked;
      row.indeterminate = false;
      this.nextAllCheck(row,idx);
      this.prevParentCheck(row,idx);
      this.$forceUpdate()
    },
    // 选中所有下一级子级元素
    nextAllCheck(row,idx){
      if(idx<this.treeColumnArr.length-1){
        for(let item of this.treeColumnArr[idx+1]){
          item.checked = row.checked;
        }
      }
    },
    // 选中所有上一级父级元素
    prevParentCheck(row,idx){
      
      if(idx>0){
        // count等于0全选，大于0未全选
        let count = 0;
        for(let item of this.treeColumnArr[idx]){
          if(!item.checked){
            count++;
          }
        }
        for(let item of this.treeColumnArr[idx-1]){
          if(item.name == row.parent_name){
            if(!count){
              item.indeterminate = false;
              console.log(1)
            }else{
              item.indeterminate = true;
              console.log(2)
            }
          }
        }
        console.log(this.treeColumnArr)
      }

    }
    

  }
})