
var initMap = function () {

    var center = new qq.maps.LatLng(39.916527, 116.397128);
    var map = new qq.maps.Map(document.getElementById('container'), {
        center: center,
        zoom: 13
    });
    var position = null,
        marker = null,
        circle = null,
        infoWin = null,
        radiusValue = '',
        geocoder = null;
    //清除覆盖物的函数
    function clearOverlays() {
        if(circle){
            circle.setMap(null);
        }
        if(marker){
            marker.setMap(null);
        }
        if(infoWin){
            infoWin.setMap(null);
        }
    }

    // console.log(qq.maps.event)
    var listener = qq.maps.event.addListener(
        map,
        'click',
        function (event) {
            clearOverlays();
            position = new qq.maps.LatLng(event.latLng.getLat(), event.latLng.getLng());
            
            
            //创建marker
            marker = new qq.maps.Marker({
                position: position,
                map: map
            });


            geocoder = new qq.maps.Geocoder({});
            geocoder.setComplete(function (result) {
                var geocoderResult = result.detail;
                infoWin = new qq.maps.InfoWindow({
                    map: map
                });
                infoWin.open();
                //tips  自定义内容
                infoWin.setContent('<div id="mapinfo" style="width:200px;">' +
                    '<p>' + geocoderResult.nearPois[0].name + '</p>' +
                    '<p>' + geocoderResult.nearPois[0].address + '</p>' +
                    '<input type="text" value="'+radiusValue+'" id="mapRadiusInput">' +
                    '</div>');
                infoWin.setPosition(position);
                // infoWin.closeclick(function(){
                //     clearOverlays();
                // });
                // console.log(infoWin)
                

            });
            geocoder.getAddress(position);
            mapCircleFun();

        function mapCircleFun(){
            circle = new qq.maps.Circle({
                //圆形的中心点坐标。
                center: position,

                //圆形是否可点击。
                clickable: true,

                //鼠标在圆形内的光标样式。
                cursor: 'pointer',

                //圆形的填充色，可通过Color对象的alpha属性设置透明度。
                // fillColor: "#00f",
                fillColor: new qq.maps.Color(40, 173, 39, 0.2),

                //要显示圆形的地图。
                map: map,

                //圆形的半径。
                radius: radiusValue || 500,

                //圆形的边框颜色，可通过Color对象的alpha属性设置透明度。
                strokeColor: "#38c82d",

                //圆形的边框样式。实线是solid，虚线是dash。
                strokeDashStyle: "solid",

                //圆形的边框线宽。
                strokeWeight: 3,
                editable: true,

                //圆形是否可见。
                visible: true,

                //圆形的zIndex值。
                zIndex: 1000
            });
        }

        }
    );

}

// Vue.component('qqMap', {
//     data() {
//       return {
//       }
//     },
//     props: {},
//     template: selectTreeTemplate,
//     mounted(){},
//     methods:{}
// })