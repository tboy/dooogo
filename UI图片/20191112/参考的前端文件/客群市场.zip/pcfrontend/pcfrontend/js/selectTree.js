var selectTreeTemplate = 
`<div class="select-tree-module">
    <div class="total-select">已选择 {{selectData.length}}/50</div>
    <div class="select-tree-content">
      <div class="tree-unit" v-for="(item,idx) in selectData" :key="idx">
        {{item.name}}
        <a href="javascript:;" @click="delSelectTree(item,idx)">删除</a>
      </div>
    </div>
    <div class="select-tree-compoent">
       

        <template v-for="(column,key) in treeColumnArr">
        <div class="tree-view">
          <ul>
            <template v-for="(item,idx) in column">
            <li :key="idx">
                <el-checkbox label="item.id" 
                  :value="item.checked" 
                  :indeterminate ="item.indeterminate"
                  @change="changeTreeSelect2(item,key)">{{item.name}}
                </el-checkbox>{{item.checked}}
            </li>
            </template>
          </ul>
        </div>
        </template>


    </div>
</div> `;


Vue.component('select-tree', {
  data() {
    return {
      treeDataArr:this.data,
      selectData:[],
      treeColumnArr:[]
    }
  },
  props: {
    data:{type:Array}
  },
  template: selectTreeTemplate,
  mounted(){
    this.createLevel('', 0)
    this.showTree('')
  },
  watch:{
  },
  methods:{
    createLevel (parent_name, level) {
      const column = []
      for(let item of this.treeDataArr){
        if(item.parent_name === parent_name){
          item.level = level
          column.push(item);
        }
      }
      if(column.length){
        column.forEach(item => {
          this.createLevel(item.name, level + 1)
        })
      }
    },
    showTree (parent_name) {
      const result = this.treeDataArr.filter(item => {
        return item.parent_name === parent_name
      })
      if(result.length){
        const level = result[0].level
        this.treeColumnArr[level] = result
        this.showTree(result[0].name, true)
      } else {
        const current = this.treeDataArr.filter(item => {
          return item.name === parent_name
        })[0]
        this.treeColumnArr = this.treeColumnArr.slice(0, current.level + 1)
      }
    },
    changeTreeSelect2 (item) {
      this.showTree(item.name)
      const level = item.level
      item.checked = !item.checked
      item.indeterminate = false
      let offset = 1
      while(this.treeColumnArr[level + offset]) {
        this.treeColumnArr[level + offset].forEach( i => {
          i.checked = item.checked
        })
        offset++
      }

      this.existParentCheck(item);
      this.getExitCheckedTree();
      
    },
    existParentCheck(item){
      if (item.level !== 0) {
        const current = this.treeDataArr.filter(i => {
          return i.name === item.parent_name
        })[0]
        const existNoCheckedChild = this.treeColumnArr[item.level].filter(i => {
          return !i.checked || i.indeterminate
        }).length > 0
        const existCheckedChild = this.treeColumnArr[item.level].filter(i => {
          return i.checked
        }).length > 0
        current.indeterminate = false
        if (existCheckedChild && !existNoCheckedChild) {
          current.checked = true
        } else if (existCheckedChild && existNoCheckedChild) {
          // current.checked = true
          current.indeterminate = true
        } else {
          current.checked = false
        }
        this.existParentCheck(current);
      }
    },
    getExitCheckedTree(){
      let existCheckedChild = [];
      let concatTreeForOne = [].concat.apply([], this.treeColumnArr);

      existCheckedChild = concatTreeForOne.filter(i => {
        return i.checked && !i.indeterminate
      })
      this.selectData = existCheckedChild;
    },
    // 删除节点
    delSelectTree(item,idx){
        this.selectData.splice(idx,1);
        this.changeTreeSelect2(item);
    }

  }
})